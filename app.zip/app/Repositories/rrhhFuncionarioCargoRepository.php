<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class rrhhFuncionarioCargoRepository extends  Repository  {




    function model()
    {
        return 'App\Models\rrhhFuncionarioCargo';
    }


}