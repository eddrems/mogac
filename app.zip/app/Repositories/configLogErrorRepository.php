<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class configLogErrorRepository extends  Repository  {




    function model()
    {
        return 'App\Models\configLogError';
    }


}