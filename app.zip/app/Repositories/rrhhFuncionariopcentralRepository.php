<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class rrhhFuncionariopcentralRepository extends  Repository  {




    function model()
    {
        return 'App\Models\rrhhFuncionariopcentral';
    }


}