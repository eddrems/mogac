<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class divEstadoInstitucionEducativaRepository extends  Repository  {




    function model()
    {
        return 'App\Models\divEstadoInstitucionEducativa';
    }


}