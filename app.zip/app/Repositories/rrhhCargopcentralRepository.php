<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class rrhhCargopcentralRepository extends  Repository  {




    function model()
    {
        return 'App\Models\rrhhCargopcentral';
    }


}