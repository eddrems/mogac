<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class rrhhFuncionarioEstadoRepository extends  Repository  {




    function model()
    {
        return 'App\Models\rrhhFuncionarioEstado';
    }


}