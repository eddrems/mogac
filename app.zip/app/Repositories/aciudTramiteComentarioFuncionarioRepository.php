<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class aciudTramiteComentarioFuncionarioRepository extends  Repository  {




    function model()
    {
        return 'App\Models\aciudTramiteComentarioFuncionario';
    }


}