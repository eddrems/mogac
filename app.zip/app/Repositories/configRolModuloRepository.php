<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class configRolModuloRepository extends  Repository  {




    function model()
    {
        return 'App\Models\configRolModulo';
    }


}