<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class configRolRepository extends  Repository  {




    function model()
    {
        return 'App\Models\configRol';
    }


}