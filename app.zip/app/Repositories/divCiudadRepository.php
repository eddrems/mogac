<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class divCiudadRepository extends  Repository  {




    function model()
    {
        return 'App\Models\divCiudad';
    }


}