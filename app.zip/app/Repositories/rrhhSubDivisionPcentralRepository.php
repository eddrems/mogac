<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class rrhhSubDivisionPcentralRepository extends  Repository  {




    function model()
    {
        return 'App\Models\rrhhSubDivisionPcentral';
    }


}