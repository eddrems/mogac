<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class comunPublicacionVisitaRepository extends  Repository  {




    function model()
    {
        return 'App\Models\comunPublicacionVisita';
    }


}