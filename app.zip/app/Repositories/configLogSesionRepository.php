<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class configLogSesionRepository extends  Repository  {




    function model()
    {
        return 'App\Models\configLogSesion';
    }


}