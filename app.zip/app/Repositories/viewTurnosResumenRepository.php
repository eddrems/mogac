<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class viewTurnosResumenRepository extends  Repository  {




    function model()
    {
        return 'App\Models\viewTurnosResumen';
    }


}