<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class rrhhCargoRepository extends  Repository  {




    function model()
    {
        return 'App\Models\rrhhCargo';
    }


}