<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class configModuloSubsistemaRepository extends  Repository  {




    function model()
    {
        return 'App\Models\configModuloSubsistema';
    }


}