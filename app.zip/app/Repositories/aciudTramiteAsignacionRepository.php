<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class aciudTramiteAsignacionRepository extends  Repository  {




    function model()
    {
        return 'App\Models\aciudTramiteAsignacion';
    }


}