<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class divZonaRepository extends  Repository  {

    function model()
    {
        return 'App\Models\divZona';
    }


}