<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class aciudAudioRepository extends  Repository  {




    function model()
    {
        return 'App\Models\aciudAudio';
    }


}