<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class aciudTramiteComentarioRepository extends  Repository  {




    function model()
    {
        return 'App\Models\aciudTramiteComentario';
    }


}