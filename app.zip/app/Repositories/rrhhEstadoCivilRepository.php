<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class rrhhEstadoCivilRepository extends  Repository  {




    function model()
    {
        return 'App\Models\rrhhEstadoCivil';
    }


}