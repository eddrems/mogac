<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class aciudVideosRepository extends  Repository  {




    function model()
    {
        return 'App\Models\aciudVideos';
    }


}