<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class aciudUsuarioRepository extends  Repository  {




    function model()
    {
        return 'App\Models\aciudUsuario';
    }


}