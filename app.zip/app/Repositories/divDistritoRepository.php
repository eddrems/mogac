<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class divDistritoRepository extends  Repository  {




    function model()
    {
        return 'App\Models\divDistrito';
    }


}