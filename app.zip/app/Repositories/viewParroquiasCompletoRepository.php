<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class viewParroquiasCompletoRepository extends  Repository  {




    function model()
    {
        return 'App\Models\viewParroquiasCompleto';
    }


}