<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class aciudEstadoTramiteRepository extends  Repository  {




    function model()
    {
        return 'App\Models\aciudEstadoTramite';
    }


}