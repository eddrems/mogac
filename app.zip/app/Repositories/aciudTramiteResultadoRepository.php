<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class aciudTramiteResultadoRepository extends  Repository  {




    function model()
    {
        return 'App\Models\aciudTramiteResultado';
    }


}