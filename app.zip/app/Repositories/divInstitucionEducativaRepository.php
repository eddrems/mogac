<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class divInstitucionEducativaRepository extends  Repository  {




    function model()
    {
        return 'App\Models\divInstitucionEducativa';
    }


}