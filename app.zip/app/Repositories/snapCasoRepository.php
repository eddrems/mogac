<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class snapCasoRepository extends  Repository  {




    function model()
    {
        return 'App\Models\snapCaso';
    }


}