<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class aciudNotificacionResolucionRepository extends  Repository  {




    function model()
    {
        return 'App\Models\aciudNotificacionResolucion';
    }




}