<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class rrhhFuncionarioDepartamentoRepository extends  Repository  {




    function model()
    {
        return 'App\Models\rrhhFuncionarioDepartamento';
    }


}