<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class aciudCalificacionServicioRepository extends  Repository  {




    function model()
    {
        return 'App\Models\aciudCalificacionServicio';
    }


}