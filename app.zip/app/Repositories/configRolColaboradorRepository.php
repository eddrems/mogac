<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class configRolColaboradorRepository extends  Repository  {




    function model()
    {
        return 'App\Models\configRolColaborador';
    }


}