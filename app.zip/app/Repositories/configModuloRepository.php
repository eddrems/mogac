<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class configModuloRepository extends  Repository  {




    function model()
    {
        return 'App\Models\configModulo';
    }


}