<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class turnTipoTurnoRepository extends  Repository  {




    function model()
    {
        return 'App\Models\turnTipoTurno';
    }


}