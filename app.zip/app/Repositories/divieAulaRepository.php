<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class divieAulaRepository extends  Repository  {




    function model()
    {
        return 'App\Models\divieAula';
    }


}