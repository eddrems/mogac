<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class rrhhFuncionarioCargopcentralRepository extends  Repository  {




    function model()
    {
        return 'App\Models\rrhhFuncionarioCargopcentral';
    }


}