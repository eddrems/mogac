<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class aciudUsuarioTipoRepository extends  Repository  {




    function model()
    {
        return 'App\Models\aciudUsuarioTipo';
    }


}