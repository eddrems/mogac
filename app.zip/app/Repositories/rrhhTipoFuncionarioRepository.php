<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class rrhhTipoFuncionarioRepository extends  Repository  {




    function model()
    {
        return 'App\Models\rrhhTipoFuncionario';
    }


}