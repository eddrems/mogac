<?php namespace App\Repositories;

use Bosnadev\Repositories\Eloquent\Repository;


class aciudTramiteRepository extends  Repository  {




    function model()
    {
        return 'App\Models\aciudTramite';
    }


}