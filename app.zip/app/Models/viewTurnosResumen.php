<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class viewTurnosResumen extends Model {

    protected $table = 'viewTurnosResumen';
    protected $primaryKey = 'id_turno';


}

