<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class viewParroquiasCompleto extends Model {

    protected $table = 'view_parroquias_completo';
    protected $primaryKey = 'id_parroquia';


}

