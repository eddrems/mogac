<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class aciudVideos extends Model {

    protected $table = 'aciud_multimedia';
    protected $primaryKey = 'id_multimedia';
    public $timestamps = false;
    //dependencias


}





