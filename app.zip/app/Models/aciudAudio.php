<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class aciudAudio extends Model {

    protected $table = 'tbl_temp_files';
    protected $primaryKey = 'id_files';
    public $timestamps = false;
    //dependencias






}